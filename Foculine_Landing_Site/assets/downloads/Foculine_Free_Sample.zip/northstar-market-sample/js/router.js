// Hash router helpers. No DOM access, so they can be tested in Node.
// Hashes: #/  #/?q=mouse&category=Audio  #/product/3  #/cart  #/checkout
//         #/order/NS-1001  #/login  #/register

export function parseHash(hash) {
  const raw = String(hash || '').replace(/^#/, '');
  const [pathPart, queryPart = ''] = raw.split('?');
  const path = '/' + pathPart.split('/').filter(Boolean).join('/');
  const params = new URLSearchParams(queryPart);

  if (path === '/') {
    return { name: 'catalogue', query: params.get('q') || '', category: params.get('category') || '' };
  }
  const productMatch = path.match(/^\/product\/([^/]+)$/);
  if (productMatch) return { name: 'product', id: decodeURIComponent(productMatch[1]) };
  const orderMatch = path.match(/^\/order\/([^/]+)$/);
  if (orderMatch) return { name: 'order', number: decodeURIComponent(orderMatch[1]) };
  if (path === '/cart') return { name: 'cart' };
  if (path === '/checkout') return { name: 'checkout' };
  if (path === '/login') return { name: 'login' };
  if (path === '/register') return { name: 'register' };
  return { name: 'notFound' };
}

export function catalogueHash({ query = '', category = '' } = {}) {
  const params = new URLSearchParams();
  if (query) params.set('q', query);
  if (category) params.set('category', category);
  const text = params.toString();
  return text ? `#/?${text}` : '#/';
}

export function productHash(id) {
  return `#/product/${encodeURIComponent(id)}`;
}

export function orderHash(number) {
  return `#/order/${encodeURIComponent(number)}`;
}
