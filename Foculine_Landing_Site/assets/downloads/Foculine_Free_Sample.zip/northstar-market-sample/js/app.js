// Application entry point: renders the screen that matches the current hash.
import { parseHash } from './router.js';
import { createStorage } from './logic/storage.js';
import { ensureSeed, getSession, logout } from './logic/auth.js';
import { loadCart, itemCount } from './logic/cart.js';
import { escapeHtml } from './logic/format.js';
import { renderCatalogue } from './ui/catalogue.js';
import { renderProduct } from './ui/product.js';
import { renderCart } from './ui/cart.js';
import { renderCheckout } from './ui/checkout.js';
import { renderOrder } from './ui/order.js';
import { renderLogin, renderRegister } from './ui/auth.js';
import { renderMessage } from './ui/message.js';
import { resetTrainingData } from './logic/reset.js';
import { navHtml } from './ui/nav.js';

const appRoot = document.getElementById('app');
const statusRegion = document.getElementById('status');
const navList = document.getElementById('nav');

const storage = createStorage(window.localStorage);
const storageOk = storage.isAvailable();
const STORAGE_NOTICE =
  'Your browser is blocking storage, so accounts, your cart and orders cannot be saved. Allow site data for this page and reload.';

let previousRouteName = null;
let currentNavRoute = '';
let pendingFlash = '';

const ctx = {
  storage,
  navigate,
  announce(text) { statusRegion.textContent = text || ''; },
  setFlash(text) { pendingFlash = text; },
  refreshNav,
};

function refreshNav() {
  navList.innerHTML = navHtml({
    email: getSession(storage),
    count: itemCount(loadCart(storage)),
    current: currentNavRoute,
  });
}

function viewFor(route) {
  switch (route.name) {
    case 'catalogue': return renderCatalogue(route, ctx);
    case 'product': return renderProduct(route, ctx);
    case 'cart': return renderCart(route, ctx);
    case 'checkout': return renderCheckout(route, ctx);
    case 'order': return renderOrder(route, ctx);
    case 'login': return renderLogin(route, ctx);
    case 'register': return renderRegister(route, ctx);
    default:
      return renderMessage({
        title: 'Page not found',
        text: 'The page you asked for does not exist.',
        linkLabel: 'Go to the shop',
        linkHref: '#/',
      });
  }
}

function navigate(hash) {
  if (window.location.hash === hash) render();
  else window.location.hash = hash;
}

function render() {
  const route = parseHash(window.location.hash);
  const sameScreen = previousRouteName === route.name && route.name === 'catalogue';
  const focusedId = sameScreen ? document.activeElement && document.activeElement.id : '';

  const flash = pendingFlash;
  pendingFlash = '';

  const view = viewFor(route);
  const banners =
    (storageOk ? '' : `<p class="notice notice--error" id="storage-notice">${escapeHtml(STORAGE_NOTICE)}</p>`) +
    (flash ? `<p class="notice notice--success" id="flash">${escapeHtml(flash)}</p>` : '');
  appRoot.innerHTML = banners + view.html;
  document.title = `${view.title} \u2013 Northstar Market`;
  statusRegion.textContent = flash || view.announce || '';

  currentNavRoute = view.navRoute;
  refreshNav();

  if (view.init) view.init(appRoot);

  if (previousRouteName !== null) {
    if (sameScreen) {
      const target = focusedId && document.getElementById(focusedId);
      if (target) {
        target.focus();
        if (target.setSelectionRange && target.type === 'search') {
          const end = target.value.length;
          target.setSelectionRange(end, end);
        }
      }
    } else {
      window.scrollTo(0, 0);
      const heading = appRoot.querySelector('h1');
      if (heading) heading.focus();
    }
  }
  previousRouteName = route.name;
}

// The skip link must not change the hash, because the hash is used for routing.
document.querySelector('.skip-link').addEventListener('click', (event) => {
  event.preventDefault();
  document.getElementById('main').focus();
});

navList.addEventListener('click', (event) => {
  if (event.target.closest('#sign-out')) {
    logout(storage);
    ctx.setFlash('You have signed out.');
    navigate('#/');
    refreshNav();
  }
});

const resetOpen = document.getElementById('reset-open');
const resetPanel = document.getElementById('reset-panel');

function closeResetPanel() {
  resetPanel.hidden = true;
  resetOpen.setAttribute('aria-expanded', 'false');
}

resetOpen.addEventListener('click', () => {
  const opening = resetPanel.hidden;
  resetPanel.hidden = !opening;
  resetOpen.setAttribute('aria-expanded', String(opening));
  if (opening) document.getElementById('reset-cancel').focus();
});
document.getElementById('reset-cancel').addEventListener('click', () => {
  closeResetPanel();
  resetOpen.focus();
});
document.getElementById('reset-confirm').addEventListener('click', async () => {
  await resetTrainingData(storage);
  closeResetPanel();
  ctx.setFlash('Practice data was reset. Only the practice account remains.');
  navigate('#/');
});

window.addEventListener('hashchange', render);

ensureSeed(storage).then(render);
