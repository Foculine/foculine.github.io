// Behaviour switches for this practice build.
// js/config.js normally sets globalThis.__nsFlags before the app runs.
// If it is missing, fall back to the same practice set so the store never
// shows more than the intended behaviour.
const PRACTICE_SET = ['f03'];

export function flag(name) {
  const chosen = globalThis.__nsFlags === undefined ? PRACTICE_SET : globalThis.__nsFlags;
  return chosen.includes(name);
}
