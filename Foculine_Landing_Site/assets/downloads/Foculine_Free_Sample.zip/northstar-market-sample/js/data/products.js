// Fixed product data for Northstar Market (fictional store, training use only).
// Prices are stored in cents so maths stays exact. This file is the single
// source of truth for every screen.

export const CATEGORIES = ['Accessories', 'Audio', 'Displays'];

export const PRODUCTS = Object.freeze([
  {
    id: 1,
    name: 'Wireless Mouse',
    category: 'Accessories',
    priceCents: 1999,
    image: 'assets/images/wireless-mouse.svg',
    description:
      'A light, comfortable mouse for everyday desk work. Connects through a small USB receiver and runs for months on one battery.',
    details: ['2.4 GHz wireless receiver', 'Right- and left-hand friendly shape', 'Quiet click buttons'],
  },
  {
    id: 2,
    name: 'Mechanical Keyboard',
    category: 'Accessories',
    priceCents: 5999,
    image: 'assets/images/mechanical-keyboard.svg',
    description:
      'A full-size keyboard with responsive mechanical switches and a sturdy frame, built for long typing sessions.',
    details: ['Full-size layout with number pad', 'Tactile mechanical switches', 'Detachable USB cable'],
  },
  {
    id: 3,
    name: 'USB-C Hub',
    category: 'Accessories',
    priceCents: 2999,
    image: 'assets/images/usb-c-hub.svg',
    description:
      'Adds extra ports to a laptop through one USB-C connection. Slim enough to keep in a laptop bag.',
    details: ['Three USB-A ports', 'HDMI video output', 'Aluminium case'],
  },
  {
    id: 4,
    name: 'Bluetooth Headphones',
    category: 'Audio',
    priceCents: 7999,
    image: 'assets/images/bluetooth-headphones.svg',
    description:
      'Over-ear headphones with soft padding and a foldable frame. Pair them with a phone or laptop in seconds.',
    details: ['Bluetooth wireless connection', 'Up to 30 hours of playback', 'Built-in microphone'],
  },
  {
    id: 5,
    name: 'Portable Speaker',
    category: 'Audio',
    priceCents: 3999,
    image: 'assets/images/portable-speaker.svg',
    description:
      'A compact speaker with clear sound for a desk, a kitchen or a picnic. Splash resistant and easy to carry.',
    details: ['Bluetooth wireless connection', 'Splash-resistant body', 'Up to 12 hours of playback'],
  },
  {
    id: 6,
    name: '24-inch Monitor',
    category: 'Displays',
    priceCents: 14999,
    image: 'assets/images/24-inch-monitor.svg',
    description:
      'A 24-inch Full HD display with a slim bezel and a stand that tilts. A solid second screen for work or study.',
    details: ['1920 x 1080 resolution', 'HDMI and DisplayPort inputs', 'Tilt-adjustable stand'],
  },
]);
