import { getProductById, detailPriceCents } from '../logic/catalogue.js';
import { formatPrice, escapeHtml } from '../logic/format.js';
import { loadCart, saveCart, addToCart, quantityOf } from '../logic/cart.js';
import { renderMessage } from './message.js';
import { SAVE_FAILED } from './cart.js';

export function renderProduct(route, ctx) {
  const product = getProductById(route.id);
  if (!product) {
    return renderMessage({
      title: 'Product not found',
      text: 'We could not find that product. It may have been removed, or the link may be wrong.',
      linkLabel: 'Back to all products',
      linkHref: '#/',
    });
  }

  const html = `
    <nav class="breadcrumb" aria-label="Breadcrumb">
      <ol>
        <li><a href="#/">Shop</a></li>
        <li><a href="#/?category=${encodeURIComponent(product.category)}">${escapeHtml(product.category)}</a></li>
        <li aria-current="page">${escapeHtml(product.name)}</li>
      </ol>
    </nav>
    <article class="product-detail" data-product-id="${product.id}">
      <div class="product-detail__image">
        <img src="${escapeHtml(product.image)}" alt="${escapeHtml(product.name)}" width="400" height="300">
      </div>
      <div class="product-detail__body">
        <p class="product-detail__category">${escapeHtml(product.category)}</p>
        <h1 tabindex="-1">${escapeHtml(product.name)}</h1>
        <p class="product-detail__price">${formatPrice(detailPriceCents(product))}</p>
        <p>${escapeHtml(product.description)}</p>
        <h2>Key details</h2>
        <ul class="product-detail__list">
          ${product.details.map((line) => `<li>${escapeHtml(line)}</li>`).join('')}
        </ul>
        <div class="product-detail__actions">
          <button class="btn" type="button" id="add-to-cart">Add to cart</button>
          <a class="btn btn--secondary" href="#/">Back to all products</a>
        </div>
        <p class="notice" id="add-feedback"></p>
      </div>
    </article>`;

  return {
    title: product.name,
    html,
    announce: '',
    navRoute: 'catalogue-detail',
    init(root) {
      const feedback = root.querySelector('#add-feedback');
      root.querySelector('#add-to-cart').addEventListener('click', () => {
        const cart = addToCart(loadCart(ctx.storage), product.id);
        if (!saveCart(ctx.storage, cart)) {
          feedback.className = 'notice notice--error';
          feedback.textContent = SAVE_FAILED;
          ctx.announce(SAVE_FAILED);
          return;
        }
        const qty = quantityOf(cart, product.id);
        const text = `${product.name} was added to your cart. You now have ${qty} in your cart.`;
        feedback.className = 'notice notice--success';
        feedback.innerHTML = `${escapeHtml(text)} <a href="#/cart">View cart</a>`;
        ctx.announce(text);
        ctx.refreshNav();
      });
    },
  };
}
