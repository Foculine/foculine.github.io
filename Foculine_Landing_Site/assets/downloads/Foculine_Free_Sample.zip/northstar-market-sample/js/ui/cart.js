import { formatPrice, escapeHtml } from '../logic/format.js';
import {
  loadCart, saveCart, increaseQuantity, decreaseQuantity, removeFromCart, cartLines, cartPageSubtotalCents, canDecrease,
} from '../logic/cart.js';
import { productHash } from '../router.js';

export const SAVE_FAILED = 'We could not save your cart because your browser is blocking storage.';

function lineHtml({ index, product, qty, lineCents }) {
  const name = escapeHtml(product.name);
  return `
    <li class="cart-item" data-product-id="${product.id}">
      <img class="cart-item__image" src="${escapeHtml(product.image)}" alt="" width="96" height="72">
      <div class="cart-item__main">
        <a class="cart-item__name" href="${productHash(product.id)}">${name}</a>
        <span class="cart-item__price">${formatPrice(product.priceCents)} each</span>
      </div>
      <div class="qty" role="group" aria-label="Quantity of ${name}">
        <button type="button" class="qty__btn" id="dec-${index}" data-action="decrease" data-index="${index}" aria-label="Decrease quantity of ${name}"${canDecrease(qty) ? '' : ' aria-disabled="true"'}>&minus;</button>
        <span class="qty__value" data-testid="qty">${qty}</span>
        <button type="button" class="qty__btn" id="inc-${index}" data-action="increase" data-index="${index}" aria-label="Increase quantity of ${name}">+</button>
      </div>
      <span class="cart-item__total" aria-label="Line total ${formatPrice(lineCents)}">${formatPrice(lineCents)}</span>
      <button type="button" class="link-button cart-item__remove" id="remove-${index}" data-action="remove" data-index="${index}">Remove<span class="visually-hidden"> ${name}</span></button>
    </li>`;
}

function cartBody(cart, message, isError) {
  const lines = cartLines(cart);
  const notice = `<p class="notice${isError ? ' notice--error' : ''}" id="cart-message">${escapeHtml(message || '')}</p>`;
  if (lines.length === 0) {
    return `${notice}
      <div class="message">
        <h2>Your cart is empty</h2>
        <p>Add a product from the shop and it will appear here.</p>
        <a class="btn" href="#/">Continue shopping</a>
      </div>`;
  }
  return `${notice}
    <ul class="cart-list" aria-label="Products in your cart">${lines.map(lineHtml).join('')}</ul>
    <div class="cart-summary">
      <p class="cart-summary__row"><span>Subtotal</span><strong id="cart-subtotal">${formatPrice(cartPageSubtotalCents(cart))}</strong></p>
      <p class="cart-summary__note">Shipping and tax are not charged in this practice store.</p>
      <div class="cart-summary__actions">
        <a class="btn" id="checkout-link" href="#/checkout">Go to checkout</a>
        <a class="btn btn--secondary" href="#/">Continue shopping</a>
      </div>
    </div>`;
}

export function renderCart(route, ctx) {
  return {
    title: 'Your cart',
    html: `<h1 tabindex="-1">Your cart</h1><div id="cart-area">${cartBody(loadCart(ctx.storage), '', false)}</div>`,
    announce: '',
    navRoute: 'cart',
    init(root) {
      const area = root.querySelector('#cart-area');

      const paint = (cart, message = '', isError = false, focusId = '') => {
        area.innerHTML = cartBody(cart, message, isError);
        if (message) ctx.announce(message);
        if (focusId) {
          const target = area.querySelector(`#${focusId}`);
          if (target) target.focus();
        }
      };

      area.addEventListener('click', (event) => {
        const button = event.target.closest('[data-action]');
        if (!button) return;
        const index = Number(button.dataset.index);
        const cart = loadCart(ctx.storage);
        const line = cartLines(cart)[index];
        if (!line) return;

        let next = cart;
        let message = '';
        let isError = false;
        let focusId = button.id;

        if (button.dataset.action === 'increase') {
          next = increaseQuantity(cart, index);
        } else if (button.dataset.action === 'decrease') {
          const result = decreaseQuantity(cart, index);
          next = result.cart;
          if (!result.changed) { message = result.reason; isError = true; }
        } else if (button.dataset.action === 'remove') {
          next = removeFromCart(cart, index);
          message = `${line.product.name} was removed from your cart.`;
          focusId = '';
        }

        if (next !== cart && !saveCart(ctx.storage, next)) {
          paint(cart, SAVE_FAILED, true, button.id);
          return;
        }
        ctx.refreshNav();
        paint(next, message, isError, focusId);
        if (button.dataset.action === 'remove') {
          const firstControl = area.querySelector('.cart-item button, .message .btn');
          if (firstControl) firstControl.focus();
        }
      });
    },
  };
}
