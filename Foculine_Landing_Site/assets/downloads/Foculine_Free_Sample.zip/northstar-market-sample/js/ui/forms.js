import { escapeHtml } from '../logic/format.js';

export function fieldHtml({ id, label, type = 'text', value = '', error = '', autocomplete = '', hint = '' }) {
  const errorId = `${id}-error`;
  const hintId = `${id}-hint`;
  const described = [hint ? hintId : '', error ? errorId : ''].filter(Boolean).join(' ');
  return `
    <div class="field${error ? ' field--error' : ''}">
      <label for="${id}">${escapeHtml(label)}</label>
      ${hint ? `<p class="field__hint" id="${hintId}">${escapeHtml(hint)}</p>` : ''}
      <input class="input" id="${id}" name="${id}" type="${type}" value="${escapeHtml(value)}"${autocomplete ? ` autocomplete="${autocomplete}"` : ''}${error ? ' aria-invalid="true"' : ''}${described ? ` aria-describedby="${described}"` : ''}>
      ${error ? `<p class="field__error" id="${errorId}">${escapeHtml(error)}</p>` : ''}
    </div>`;
}

// A box listing every problem with a form. Field problems link to their field.
export function errorSummaryHtml({ title, errors, order }) {
  const keys = Object.keys(errors);
  if (keys.length === 0) return '';
  const ordered = [...order.filter((key) => errors[key]), ...keys.filter((key) => !order.includes(key))];
  const items = ordered
    .map((key) => (key === 'form'
      ? `<li>${escapeHtml(errors[key])}</li>`
      : `<li><button type="button" class="link-button" data-focus="${key}">${escapeHtml(errors[key])}</button></li>`))
    .join('');
  return `<div class="error-summary" id="error-summary" tabindex="-1" aria-labelledby="error-summary-title">
      <h2 id="error-summary-title">${escapeHtml(title)}</h2><ul>${items}</ul></div>`;
}

// Call after the form HTML is on the page.
export function wireForm(root, onSubmit) {
  const form = root.querySelector('form');
  let busy = false;
  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (busy) return;
    busy = true;
    try {
      await onSubmit(Object.fromEntries(new FormData(form).entries()));
    } finally {
      busy = false;
    }
  });
  root.querySelectorAll('[data-focus]').forEach((button) => {
    button.addEventListener('click', () => {
      const target = root.querySelector(`#${button.dataset.focus}`);
      if (target) target.focus();
    });
  });
  const summary = root.querySelector('#error-summary');
  if (summary) summary.focus();
}
