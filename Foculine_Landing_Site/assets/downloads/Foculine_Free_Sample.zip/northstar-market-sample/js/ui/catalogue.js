import { findProducts, getCategories } from '../logic/catalogue.js';
import { formatPrice, escapeHtml } from '../logic/format.js';
import { catalogueHash, productHash } from '../router.js';

function summaryText(count, query, category) {
  const noun = count === 1 ? 'product' : 'products';
  let text = `${count} ${noun}`;
  if (category) text += ` in ${category}`;
  if (query) text += ` matching \u201C${query}\u201D`;
  return text;
}

function cardHtml(product) {
  return `
    <li class="card" data-product-id="${product.id}">
      <div class="card__image"><img src="${escapeHtml(product.image)}" alt="" width="400" height="300" loading="lazy"></div>
      <div class="card__body">
        <span class="card__category">${escapeHtml(product.category)}</span>
        <h2 class="card__name"><a href="${productHash(product.id)}">${escapeHtml(product.name)}</a></h2>
        <span class="card__price">${formatPrice(product.priceCents)}</span>
      </div>
    </li>`;
}

export function renderCatalogue(route, ctx) {
  const query = (route.query || '').trim();
  const categories = getCategories();
  const category = categories.includes(route.category) ? route.category : '';
  const products = findProducts({ query, category });
  const summary = summaryText(products.length, query, category);

  const chips = [{ label: 'All', value: '' }, ...categories.map((c) => ({ label: c, value: c }))]
    .map((item) => {
      const current = item.value === category;
      const id = `filter-${item.value || 'all'}`;
      return `<li><a class="chip" id="${id}" href="${catalogueHash({ query, category: item.value })}" aria-current="${current}">${escapeHtml(item.label)}</a></li>`;
    })
    .join('');

  const results = products.length
    ? `<ul class="product-grid" aria-label="Products">${products.map(cardHtml).join('')}</ul>`
    : `<div class="message">
         <h2>No products found</h2>
         <p>Nothing matches your search. Check the spelling, try a shorter search, or remove the category filter.</p>
         <a class="btn" href="#/">Show all products</a>
       </div>`;

  const html = `
    <div class="page-intro">
      <h1 tabindex="-1">Shop all products</h1>
      <p>Desk and audio essentials for work, study and play.</p>
    </div>
    <div class="toolbar">
      <form class="search" role="search" id="search-form" novalidate>
        <div class="field">
          <label for="search-q">Search products</label>
          <input class="input" id="search-q" name="q" type="search" value="${escapeHtml(query)}" autocomplete="off">
        </div>
        <button class="btn" type="submit">Search</button>
      </form>
      <nav aria-label="Product categories"><ul class="filters">${chips}</ul></nav>
    </div>
    <p class="result-summary">${escapeHtml(summary)}</p>
    ${results}`;

  return {
    title: 'Shop',
    html,
    announce: summary,
    navRoute: 'catalogue',
    init(root) {
      root.querySelector('#search-form').addEventListener('submit', (event) => {
        event.preventDefault();
        const value = root.querySelector('#search-q').value.trim();
        ctx.navigate(catalogueHash({ query: value, category }));
      });
    },
  };
}
