import { escapeHtml } from '../logic/format.js';

// A simple full-width message screen (not found, placeholders).
export function renderMessage({ title, text, linkLabel, linkHref, navRoute = '' }) {
  const link = linkLabel ? `<a class="btn" href="${escapeHtml(linkHref)}">${escapeHtml(linkLabel)}</a>` : '';
  return {
    title,
    html: `<div class="message"><h1 tabindex="-1">${escapeHtml(title)}</h1><p>${escapeHtml(text)}</p>${link}</div>`,
    announce: '',
    navRoute,
  };
}
