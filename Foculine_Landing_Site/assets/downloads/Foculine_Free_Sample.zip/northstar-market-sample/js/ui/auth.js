import { login, register, getSession, SEED_ACCOUNT } from '../logic/auth.js';
import { escapeHtml } from '../logic/format.js';
import { fieldHtml, errorSummaryHtml, wireForm } from './forms.js';
import { renderMessage } from './message.js';

function signedInView(email, navRoute) {
  return renderMessage({
    title: 'You are already signed in',
    text: `You are signed in as ${email}. Use Sign out in the header if you want to switch accounts.`,
    linkLabel: 'Continue shopping',
    linkHref: '#/',
    navRoute,
  });
}

function loginForm({ values = {}, errors = {} }) {
  return `
    ${errorSummaryHtml({ title: 'We could not sign you in', errors, order: ['form', 'email', 'password'] })}
    <form id="login-form" novalidate>
      ${fieldHtml({ id: 'email', label: 'Email', type: 'email', value: values.email || '', error: errors.email, autocomplete: 'username' })}
      ${fieldHtml({ id: 'password', label: 'Password', type: 'password', error: errors.password, autocomplete: 'current-password' })}
      <button class="btn" type="submit">Sign in</button>
    </form>`;
}

export function renderLogin(route, ctx) {
  const current = getSession(ctx.storage);
  if (current) return signedInView(current, 'login');

  const html = `
    <div class="auth">
      <h1 tabindex="-1">Sign in</h1>
      <div id="form-area">${loginForm({})}</div>
      <p class="auth__switch">New to Northstar Market? <a href="#/register">Create an account</a></p>
      <aside class="practice-box" aria-labelledby="practice-title">
        <h2 id="practice-title">Practice account</h2>
        <p>Use these fictional details to sign in while you practise:</p>
        <dl>
          <div><dt>Email</dt><dd>${escapeHtml(SEED_ACCOUNT.email)}</dd></div>
          <div><dt>Password</dt><dd>${escapeHtml(SEED_ACCOUNT.password)}</dd></div>
        </dl>
      </aside>
    </div>`;

  return {
    title: 'Sign in',
    html,
    announce: '',
    navRoute: 'login',
    init(root) {
      const area = root.querySelector('#form-area');
      const bind = () => wireForm(area, async (values) => {
        const result = await login(ctx.storage, values);
        if (result.ok) {
          ctx.setFlash(`Signed in as ${result.email}.`);
          ctx.refreshNav();
          ctx.navigate('#/');
          return;
        }
        area.innerHTML = loginForm({ values: { email: values.email }, errors: result.errors });
        bind();
      });
      bind();
    },
  };
}

function registerForm({ values = {}, errors = {} }) {
  return `
    ${errorSummaryHtml({ title: 'We could not create your account', errors, order: ['form', 'email', 'password'] })}
    <form id="register-form" novalidate>
      ${fieldHtml({ id: 'email', label: 'Email', type: 'email', value: values.email || '', error: errors.email, autocomplete: 'username' })}
      ${fieldHtml({ id: 'password', label: 'Password', type: 'password', error: errors.password, autocomplete: 'new-password', hint: 'Use 8 or more characters, with at least one letter and one number.' })}
      <button class="btn" type="submit">Create account</button>
    </form>`;
}

export function renderRegister(route, ctx) {
  const current = getSession(ctx.storage);
  if (current) return signedInView(current, 'register');

  const html = `
    <div class="auth">
      <h1 tabindex="-1">Create an account</h1>
      <p class="auth__intro">Use a made-up email address. Accounts are stored only in this browser.</p>
      <div id="form-area">${registerForm({})}</div>
      <p class="auth__switch">Already registered? <a href="#/login">Sign in</a></p>
    </div>`;

  return {
    title: 'Create an account',
    html,
    announce: '',
    navRoute: 'register',
    init(root) {
      const area = root.querySelector('#form-area');
      const bind = () => wireForm(area, async (values) => {
        const result = await register(ctx.storage, values);
        if (result.ok) {
          ctx.setFlash('Account created. Sign in with your new email and password.');
          ctx.navigate('#/login');
          return;
        }
        area.innerHTML = registerForm({ values: { email: values.email }, errors: result.errors });
        bind();
      });
      bind();
    },
  };
}
