import { formatPrice, escapeHtml } from '../logic/format.js';
import { getOrder, displayTotalCents } from '../logic/orders.js';
import { renderMessage } from './message.js';

export function renderOrder(route, ctx) {
  const order = getOrder(ctx.storage, route.number);
  if (!order) {
    return renderMessage({
      title: 'Order not found',
      text: 'We could not find that order. Orders are stored only in the browser where they were placed.',
      linkLabel: 'Go to the shop',
      linkHref: '#/',
    });
  }
  const c = order.customer;
  const rows = order.items.map((item) => `
    <tr>
      <th scope="row">${escapeHtml(item.name)}</th>
      <td>${item.qty}</td>
      <td>${formatPrice(item.priceCents)}</td>
      <td>${formatPrice(item.lineCents)}</td>
    </tr>`).join('');

  return {
    title: `Order ${order.number}`,
    html: `
      <div class="confirmation">
        <h1 tabindex="-1">Thank you for your order</h1>
        <p>Your order number is <strong id="order-number">${escapeHtml(order.number)}</strong>. This is a practice store, so nothing is charged and no email is sent.</p>
        <div class="table-wrap">
          <table class="order-table">
            <caption class="visually-hidden">Items in order ${escapeHtml(order.number)}</caption>
            <thead><tr><th scope="col">Product</th><th scope="col">Quantity</th><th scope="col">Price</th><th scope="col">Total</th></tr></thead>
            <tbody>${rows}</tbody>
          </table>
        </div>
        <p class="cart-summary__row"><span>Order total</span><strong id="order-total">${formatPrice(displayTotalCents(order))}</strong></p>
        <section aria-labelledby="ship-title" class="ship">
          <h2 id="ship-title">Shipping to</h2>
          <p id="order-shipping">${escapeHtml(c.name)}<br>${escapeHtml(c.address)}<br>${escapeHtml(c.city)} ${escapeHtml(c.postalCode)}<br>${escapeHtml(c.email)}</p>
        </section>
        <a class="btn" href="#/">Continue shopping</a>
      </div>`,
    announce: '',
    navRoute: '',
  };
}
