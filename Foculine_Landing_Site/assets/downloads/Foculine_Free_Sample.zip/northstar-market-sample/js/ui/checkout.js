import { formatPrice, escapeHtml } from '../logic/format.js';
import { loadCart, activeLines } from '../logic/cart.js';
import { placeOrder } from '../logic/orders.js';
import { getSession } from '../logic/auth.js';
import { CHECKOUT_FIELDS } from '../logic/validation.js';
import { orderHash } from '../router.js';
import { fieldHtml, errorSummaryHtml, wireForm } from './forms.js';
import { renderMessage } from './message.js';

function summaryHtml(cart) {
  const lines = activeLines(cart);
  const total = lines.reduce((sum, line) => sum + line.lineCents, 0);
  return `
    <section class="order-summary" aria-labelledby="summary-title">
      <h2 id="summary-title">Order summary</h2>
      <ul class="order-summary__list">
        ${lines.map((line) => `
          <li><span>${escapeHtml(line.product.name)} <span class="muted">&times; ${line.qty}</span></span><span>${formatPrice(line.lineCents)}</span></li>`).join('')}
      </ul>
      <p class="cart-summary__row"><span>Total</span><strong id="checkout-total">${formatPrice(total)}</strong></p>
      <p class="cart-summary__note">Shipping and tax are not charged in this practice store.</p>
      <p><a href="#/cart">Change your cart</a></p>
    </section>`;
}

function formHtml({ values = {}, errors = {} }) {
  const f = (id, label, extra = {}) =>
    fieldHtml({ id, label, value: values[id] || '', error: errors[id], ...extra });
  return `
    ${errorSummaryHtml({ title: 'Please fix the following', errors, order: ['form', ...CHECKOUT_FIELDS] })}
    <form id="checkout-form" novalidate>
      ${f('name', 'Full name', { autocomplete: 'name' })}
      ${f('email', 'Email', { type: 'email', autocomplete: 'email' })}
      ${f('address', 'Street address', { autocomplete: 'street-address' })}
      ${f('city', 'City', { autocomplete: 'address-level2' })}
      ${f('postalCode', 'Postal code', { autocomplete: 'postal-code' })}
      <p class="cart-summary__note">This is a practice store. No payment is taken.</p>
      <button class="btn" type="submit">Place order</button>
    </form>`;
}

export function renderCheckout(route, ctx) {
  const cart = loadCart(ctx.storage);
  if (activeLines(cart).length === 0) {
    return renderMessage({
      title: 'Checkout',
      text: 'Your cart is empty, so there is nothing to check out yet. Add a product first.',
      linkLabel: 'Continue shopping',
      linkHref: '#/',
      navRoute: 'cart',
    });
  }
  const email = getSession(ctx.storage);

  return {
    title: 'Checkout',
    html: `
      <h1 tabindex="-1">Checkout</h1>
      <div class="checkout">
        <div id="form-area">${formHtml({ values: { email } })}</div>
        ${summaryHtml(cart)}
      </div>`,
    announce: '',
    navRoute: 'cart',
    init(root) {
      const area = root.querySelector('#form-area');
      const bind = () => wireForm(area, async (values) => {
        const result = placeOrder(ctx.storage, loadCart(ctx.storage), values);
        if (result.ok) {
          ctx.refreshNav();
          ctx.navigate(orderHash(result.order.number));
          return;
        }
        area.innerHTML = formHtml({ values, errors: result.errors });
        bind();
      });
      bind();
    },
  };
}
