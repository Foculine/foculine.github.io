import { escapeHtml } from '../logic/format.js';

export function navHtml({ email, count, current }) {
  const link = (route, href, label) =>
    `<li><a href="${href}" data-route="${route}"${current === route ? ' aria-current="page"' : ''}>${label}</a></li>`;
  const cartLabel = count
    ? `Cart<span class="badge" aria-hidden="true">${count}</span><span class="visually-hidden"> (${count} ${count === 1 ? 'item' : 'items'})</span>`
    : 'Cart';
  const account = email
    ? `<li><span class="nav__user">${escapeHtml(email)}</span></li>
       <li><button type="button" class="nav__button" id="sign-out">Sign out</button></li>`
    : `${link('login', '#/login', 'Sign in')}${link('register', '#/register', 'Register')}`;
  return `${link('catalogue', '#/', 'Shop')}${link('cart', '#/cart', cartLabel)}${account}`;
}
