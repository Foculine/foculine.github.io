import { flag } from '../flags.js';

// Validation rules. Every function returns { valid, errors, values }.
// `errors` maps a field name to one plain-language message.

export const MESSAGES = Object.freeze({
  emailRequired: 'Enter your email address.',
  emailInvalid: 'Enter a valid email address, like name@example.com.',
  passwordRequired: 'Enter your password.',
  passwordShort: 'Use at least 8 characters for your password.',
  passwordLong: 'Use no more than 64 characters for your password.',
  passwordMix: 'Include at least one letter and one number in your password.',
  nameRequired: 'Enter your full name.',
  addressRequired: 'Enter your street address.',
  cityRequired: 'Enter your city.',
  postalRequired: 'Enter your postal code.',
  postalInvalid: 'Enter a valid postal code, using 3 to 10 letters, numbers, spaces or hyphens.',
  tooLong: 'This is too long. Use 100 characters or fewer.',
});

const EMAIL_PATTERN = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)*\.[A-Za-z]{2,}$/;

export function normaliseEmail(value) {
  return String(value ?? '').trim().toLowerCase();
}

export function checkEmail(value) {
  const email = String(value ?? '').trim();
  if (!email) return MESSAGES.emailRequired;
  const [local = ''] = email.split('@');
  if (email.length > 254 || email.includes('..') || local.startsWith('.') || local.endsWith('.') || !EMAIL_PATTERN.test(email)) {
    return MESSAGES.emailInvalid;
  }
  return '';
}

export function checkNewPassword(value) {
  const password = String(value ?? '');
  if (!password) return MESSAGES.passwordRequired;
  if (password.length < 8) return MESSAGES.passwordShort;
  if (password.length > 64) return MESSAGES.passwordLong;
  if (!/[A-Za-z]/.test(password) || !/[0-9]/.test(password)) return MESSAGES.passwordMix;
  return '';
}

function result(errors, values) {
  const clean = Object.fromEntries(Object.entries(errors).filter(([, message]) => message));
  return { valid: Object.keys(clean).length === 0, errors: clean, values };
}

export function validateRegistration({ email, password } = {}) {
  const emailProblem = flag('f01')
    ? (String(email ?? '').trim() ? '' : MESSAGES.emailRequired)
    : checkEmail(email);
  return result(
    { email: emailProblem, password: checkNewPassword(password) },
    { email: normaliseEmail(email), password: String(password ?? '') },
  );
}

// Login only checks that the fields are filled in and the email looks like an email.
// It does not judge password strength: that is only for new passwords.
export function validateLogin({ email, password } = {}) {
  return result(
    { email: checkEmail(email), password: String(password ?? '') ? '' : MESSAGES.passwordRequired },
    { email: normaliseEmail(email), password: String(password ?? '') },
  );
}

function required(value, message) {
  const text = String(value ?? '').trim();
  if (!text) return message;
  if (text.length > 100) return MESSAGES.tooLong;
  return '';
}

export function checkPostalCode(value) {
  const text = String(value ?? '').trim();
  if (!text) return flag('f09') ? '' : MESSAGES.postalRequired;
  if (!/^[A-Za-z0-9][A-Za-z0-9 -]{2,9}$/.test(text)) return MESSAGES.postalInvalid;
  return '';
}

export const CHECKOUT_FIELDS = ['name', 'email', 'address', 'city', 'postalCode'];

export function validateCheckout(input = {}) {
  const values = {
    name: String(input.name ?? '').trim(),
    email: normaliseEmail(input.email),
    address: String(input.address ?? '').trim(),
    city: String(input.city ?? '').trim(),
    postalCode: String(input.postalCode ?? '').trim(),
  };
  return result(
    {
      name: required(values.name, MESSAGES.nameRequired),
      email: checkEmail(values.email),
      address: required(values.address, MESSAGES.addressRequired),
      city: required(values.city, MESSAGES.cityRequired),
      postalCode: checkPostalCode(values.postalCode),
    },
    values,
  );
}
