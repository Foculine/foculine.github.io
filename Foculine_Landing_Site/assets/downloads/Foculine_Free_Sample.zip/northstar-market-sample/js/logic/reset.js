// Restores the original training data: removes every Northstar key, then recreates the practice account.
import { ensureSeed } from './auth.js';
import { clearSessionCart } from './cart.js';

export async function resetTrainingData(storage) {
  storage.clearAll();
  clearSessionCart();
  await ensureSeed(storage);
}
