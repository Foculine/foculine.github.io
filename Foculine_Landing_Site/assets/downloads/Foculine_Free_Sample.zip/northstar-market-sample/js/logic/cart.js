// Cart logic. The cart is a plain list: [{ productId, qty }]. Functions return a new
// list and never change the one passed in. Lines are addressed by their position (index).
// Money is in cents.
import { flag } from '../flags.js';
import { getProductById } from './catalogue.js';
import { KEYS } from './storage.js';

export const CART_MESSAGES = Object.freeze({
  minimum: 'Quantity cannot be less than 1. Use Remove to take this product out of your cart.',
});

// Keeps only entries for real products with a whole-number quantity of 1 or more,
// and merges repeated products. Protects the app from damaged stored data.
export function sanitiseCart(raw) {
  if (!Array.isArray(raw)) return [];
  const lowest = flag('f07') ? 0 : 1;
  const merge = !flag('f06');
  const lines = [];
  for (const entry of raw) {
    const id = Number(entry && entry.productId);
    const qty = Number(entry && entry.qty);
    if (!getProductById(id) || !Number.isInteger(qty) || qty < lowest) continue;
    const existing = merge ? lines.find((line) => line.productId === id) : undefined;
    if (existing) existing.qty += qty;
    else lines.push({ productId: id, qty });
  }
  return lines;
}

export function addToCart(cart, productId) {
  if (!getProductById(productId)) return cart;
  const id = Number(productId);
  const at = cart.findIndex((line) => line.productId === id);
  if (at !== -1 && !flag('f06')) {
    return cart.map((line, i) => (i === at ? { ...line, qty: line.qty + 1 } : line));
  }
  return [...cart, { productId: id, qty: 1 }];
}

export function increaseQuantity(cart, index) {
  return cart.map((line, i) => (i === index ? { ...line, qty: line.qty + 1 } : line));
}

// True when the minus button should work for a line with this quantity.
export function canDecrease(qty) {
  return qty > (flag('f07') ? 0 : 1);
}

// When the quantity is already at the lowest allowed value the cart is returned unchanged
// with a reason; Remove is the way to delete a line.
export function decreaseQuantity(cart, index) {
  const line = cart[index];
  if (!line) return { cart, changed: false, reason: '' };
  if (!canDecrease(line.qty)) return { cart, changed: false, reason: CART_MESSAGES.minimum };
  return {
    cart: cart.map((item, i) => (i === index ? { ...item, qty: item.qty - 1 } : item)),
    changed: true,
    reason: '',
  };
}

export function removeFromCart(cart, index) {
  return cart.filter((line, i) => i !== index);
}

export function cartLines(cart) {
  return cart.map((line, index) => {
    const product = getProductById(line.productId);
    return { index, product, qty: line.qty, lineCents: product.priceCents * line.qty };
  });
}

// Lines that will actually be bought: quantity of at least 1.
export function activeLines(cart) {
  return cartLines(cart).filter((line) => line.qty >= 1);
}

export function subtotalCents(cart) {
  return cartLines(cart).reduce((sum, line) => sum + line.lineCents, 0);
}

// The subtotal shown on the cart page.
export function cartPageSubtotalCents(cart) {
  if (!flag('f08')) return subtotalCents(cart);
  return cartLines(cart).reduce((sum, line) => sum + (line.qty >= 1 ? line.product.priceCents : 0), 0);
}

export function itemCount(cart) {
  return cart.reduce((sum, line) => sum + line.qty, 0);
}

export function quantityOf(cart, productId) {
  return cart.filter((line) => line.productId === Number(productId)).reduce((sum, line) => sum + line.qty, 0);
}

let sessionCart = [];

export function clearSessionCart() {
  sessionCart = [];
}

export function loadCart(storage) {
  if (flag('f11')) return sanitiseCart(sessionCart);
  return sanitiseCart(storage.read(KEYS.cart, []));
}

// Returns true if saved.
export function saveCart(storage, cart) {
  if (flag('f11')) {
    sessionCart = cart;
    return true;
  }
  return storage.write(KEYS.cart, cart);
}
