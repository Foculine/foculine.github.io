// Thin wrapper around localStorage so logic can be tested without a browser.
// All keys start with "ns." so reset can remove exactly the app's own data.
// Limitation: data is per browser and per site, and clearing site data erases it.

const PREFIX = 'ns.';

export const KEYS = Object.freeze({
  users: 'users',
  session: 'session',
  cart: 'cart',
  orders: 'orders',
});

export function memoryBackend() {
  const map = new Map();
  return {
    getItem: (k) => (map.has(k) ? map.get(k) : null),
    setItem: (k, v) => { map.set(k, String(v)); },
    removeItem: (k) => { map.delete(k); },
    key: (i) => [...map.keys()][i] ?? null,
    get length() { return map.size; },
  };
}

export function createStorage(backend) {
  return {
    // Returns the stored value, or `fallback` if missing, unreadable or the browser blocks storage.
    read(key, fallback) {
      try {
        const raw = backend.getItem(PREFIX + key);
        return raw === null ? fallback : JSON.parse(raw);
      } catch {
        return fallback;
      }
    },
    // Returns true if saved, false if the browser refused.
    write(key, value) {
      try {
        backend.setItem(PREFIX + key, JSON.stringify(value));
        return true;
      } catch {
        return false;
      }
    },
    remove(key) {
      try { backend.removeItem(PREFIX + key); } catch { /* nothing to do */ }
    },
    clearAll() {
      try {
        const keys = [];
        for (let i = 0; i < backend.length; i += 1) keys.push(backend.key(i));
        keys.filter((k) => k && k.startsWith(PREFIX)).forEach((k) => backend.removeItem(k));
      } catch { /* nothing to do */ }
    },
    isAvailable() {
      try {
        const probe = `${PREFIX}probe`;
        backend.setItem(probe, '1');
        backend.removeItem(probe);
        return true;
      } catch {
        return false;
      }
    },
  };
}
