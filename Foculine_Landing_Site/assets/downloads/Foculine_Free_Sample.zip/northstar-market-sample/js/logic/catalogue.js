// Catalogue logic: lookup, search and category filtering. No DOM access.
import { PRODUCTS, CATEGORIES } from '../data/products.js';
import { flag } from '../flags.js';

export function getAllProducts() {
  return PRODUCTS;
}

export function getCategories() {
  return CATEGORIES;
}

// Returns the product, or undefined if the id is not a whole number that exists.
export function getProductById(id) {
  const text = String(id);
  if (!/^\d+$/.test(text)) return undefined;
  const number = Number(text);
  return PRODUCTS.find((product) => product.id === number);
}

// Search rule: every word in the query must appear in the product name or
// category (case-insensitive). An empty query matches everything.
export function matchesQuery(product, query) {
  const words = String(query || '').toLowerCase().split(/\s+/).filter(Boolean);
  if (words.length === 0) return true;
  const haystack = `${product.name} ${product.category}`.toLowerCase();
  return words.every((word) => haystack.includes(word));
}

// Category rule: an empty or unknown category means "all products".
export function matchesCategory(product, category) {
  if (!category || !CATEGORIES.includes(category)) return true;
  if (flag('f04') && category === 'Audio') return product.category === 'Audio' || product.category === 'Accessories';
  return product.category === category;
}

export function findProducts({ query = '', category = '' } = {}) {
  let found = PRODUCTS.filter((product) => matchesQuery(product, query));
  if (flag('f03') && String(query || '').trim()) {
    const groups = new Set(found.map((product) => product.category));
    found = PRODUCTS.filter((product) => groups.has(product.category));
  }
  return found.filter((product) => matchesCategory(product, category));
}

// The price shown on a product's own page.
export function detailPriceCents(product) {
  return flag('f05') && product.id === 4 ? 8999 : product.priceCents;
}
