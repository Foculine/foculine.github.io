// Fictional accounts only. Passwords are never stored as plain text: each account
// keeps a random salt and a SHA-256 hash made with the browser's Web Crypto.
// This is a training simulation, not real security: everything lives in this browser.
import { flag } from '../flags.js';
import { KEYS } from './storage.js';
import { validateRegistration, validateLogin, normaliseEmail } from './validation.js';

export const SEED_ACCOUNT = Object.freeze({ email: 'tester@example.com', password: 'Test1234!' });
const SEED_SALT = 'northstar-seed-salt';

export const AUTH_MESSAGES = Object.freeze({
  duplicate: 'An account with this email already exists. Sign in, or use a different email.',
  badLogin: 'Incorrect email or password. Check your details and try again.',
  saveFailed: 'We could not save your account because your browser is blocking storage.',
});

function toHex(buffer) {
  return [...new Uint8Array(buffer)].map((b) => b.toString(16).padStart(2, '0')).join('');
}

export async function hashPassword(password, salt) {
  const data = new TextEncoder().encode(`${salt}:${password}`);
  return toHex(await globalThis.crypto.subtle.digest('SHA-256', data));
}

function newSalt() {
  return toHex(globalThis.crypto.getRandomValues(new Uint8Array(16)));
}

// Creates the practice account if it is not there yet. Safe to call every time.
export async function ensureSeed(storage) {
  const users = storage.read(KEYS.users, null);
  if (Array.isArray(users) && users.some((u) => u.email === SEED_ACCOUNT.email)) return;
  const seeded = {
    email: SEED_ACCOUNT.email,
    salt: SEED_SALT,
    hash: await hashPassword(SEED_ACCOUNT.password, SEED_SALT),
  };
  storage.write(KEYS.users, [seeded, ...(Array.isArray(users) ? users : [])]);
}

export async function register(storage, input) {
  const check = validateRegistration(input);
  if (!check.valid) return { ok: false, errors: check.errors };

  const users = storage.read(KEYS.users, []);
  if (users.some((u) => u.email === check.values.email)) {
    return { ok: false, errors: flag('f12') ? {} : { email: AUTH_MESSAGES.duplicate } };
  }
  const salt = newSalt();
  const hash = await hashPassword(check.values.password, salt);
  const saved = storage.write(KEYS.users, [...users, { email: check.values.email, salt, hash }]);
  if (!saved) return { ok: false, errors: { form: AUTH_MESSAGES.saveFailed } };
  return { ok: true, email: check.values.email };
}

export async function login(storage, input) {
  const check = validateLogin(input);
  if (!check.valid) return { ok: false, errors: check.errors };

  const users = storage.read(KEYS.users, []);
  const user = users.find((u) => u.email === check.values.email);
  const hash = user ? await hashPassword(check.values.password, user.salt) : null;
  const matches = Boolean(user) && hash === user.hash;
  if (!user || (!matches && !flag('f02'))) {
    return { ok: false, errors: { form: AUTH_MESSAGES.badLogin } };
  }
  storage.write(KEYS.session, { email: user.email });
  return { ok: true, email: user.email };
}

export function getSession(storage) {
  const session = storage.read(KEYS.session, null);
  return session && typeof session.email === 'string' ? normaliseEmail(session.email) : '';
}

export function logout(storage) {
  storage.remove(KEYS.session);
}
