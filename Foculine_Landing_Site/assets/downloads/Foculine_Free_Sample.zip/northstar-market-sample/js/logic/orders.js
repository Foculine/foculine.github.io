// Order placement. Orders are simulated: nothing is charged and nothing is sent anywhere.
// Order numbers are sequential (NS-1001, NS-1002, ...) so results are repeatable.
import { flag } from '../flags.js';
import { KEYS } from './storage.js';
import { validateCheckout } from './validation.js';
import { activeLines, saveCart } from './cart.js';

export const FIRST_ORDER_NUMBER = 1001;

export const ORDER_MESSAGES = Object.freeze({
  emptyCart: 'Your cart is empty. Add a product before you check out.',
  saveFailed: 'We could not place your order because your browser is blocking storage.',
});

export function loadOrders(storage) {
  const orders = storage.read(KEYS.orders, []);
  return Array.isArray(orders) ? orders : [];
}

export function getOrder(storage, number) {
  return loadOrders(storage).find((order) => order.number === number);
}

// The total shown on the confirmation page.
export function displayTotalCents(order) {
  return flag('f10') ? order.totalCents + 500 : order.totalCents;
}

export function placeOrder(storage, cart, customer) {
  const check = validateCheckout(customer);
  if (!check.valid) return { ok: false, errors: check.errors };

  const lines = activeLines(cart);
  if (lines.length === 0) return { ok: false, errors: { form: ORDER_MESSAGES.emptyCart } };

  const orders = loadOrders(storage);
  const order = {
    number: `NS-${FIRST_ORDER_NUMBER + orders.length}`,
    items: lines.map((line) => ({
      productId: line.product.id,
      name: line.product.name,
      priceCents: line.product.priceCents,
      qty: line.qty,
      lineCents: line.lineCents,
    })),
    totalCents: lines.reduce((sum, line) => sum + line.lineCents, 0),
    customer: check.values,
  };

  if (!storage.write(KEYS.orders, [...orders, order])) {
    return { ok: false, errors: { form: ORDER_MESSAGES.saveFailed } };
  }
  saveCart(storage, []);
  return { ok: true, order };
}
