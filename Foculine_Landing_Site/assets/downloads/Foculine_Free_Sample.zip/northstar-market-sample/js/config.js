// Free sample build: choose which behaviour switches are on.
// Runs as a classic script, so it is evaluated before the app modules.
globalThis.__nsFlags = ['f03'];
