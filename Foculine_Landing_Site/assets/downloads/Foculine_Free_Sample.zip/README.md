# Foculine: The 20-Minute QA Challenge (free sample)

Test an online store like a real QA tester. Learn it. Practise it. Prove it.

## What is in this folder
| File | What it is |
|---|---|
| `Foculine_20_Minute_QA_Challenge.pdf` | The guide: read this first |
| `Foculine_Test_Execution_Sheet.xlsx` | Where you record your results and a bug report |
| `northstar-market-sample/` | The practice store you will test |

## Start the store
You need Python 3 (free from python.org). Open a terminal in this folder (the one that contains `northstar-market-sample`) and run:

    python3 -m http.server 8080 --directory northstar-market-sample

On Windows, if `python3` is not found, use `python` or `py` instead. Then open **http://localhost:8080** in Chrome or Edge. Use `localhost`. Press Ctrl+C in the terminal to stop the server.

Do not open `index.html` by double-clicking it: the store needs the web address above.

## How to use it
1. Read the PDF (about 20 minutes in total).
2. Run the three test cases against the store and record what you see in the spreadsheet.
3. If a test fails, write a bug report on the "Bug Report" tab.

Test the store through the screen only. Reading the source code defeats the exercise, because a real tester judges behaviour against requirements.

## Good to know
- Northstar Market is fictional. No real orders, payments or customer data are used, and everything stays in your own browser.
- **Reset practice data** (bottom of every page) returns the store to its starting state.
- Tested in Chrome. If you use another browser, say so in your results.
- This is self-directed practice. It has no answer sheet, grade or certificate.
